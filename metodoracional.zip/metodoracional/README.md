# MetodoRacional
Calcula a vazão de projeto de acordo com o método racional, usualmente aplicável à bacias com área de até 2 Km². Os inputs necessários são: canal principal (talvegue), contorno da bacia, raster de modelo digital de elevação (MDE) e raster de curve number com escala de 0 a 100.
