from qgis.core import QgsVectorLayer, QgsProject, QgsRasterLayer
from qgis.analysis import QgsRasterCalculator
from qgis.PyQt.QtWidgets import QMessageBox
import processing


import os
from qgis.core import QgsProject


def run_your_code():
    # Verifica se o projeto atual tem um caminho de arquivo associado
    if not QgsProject.instance().fileName():
        # Se não tiver um caminho de arquivo, o projeto não foi salvo
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText("O projeto não foi salvo.")
        msg.setInformativeText("Você deve salvar o seu projeto antes de continuar.")
        msg.setStandardButtons(QMessageBox.Cancel)

        
        # Exibe a caixa de diálogo e obtém a resposta do usuário
        ret = msg.exec_()

        return False
    else:
        return True


def delete_shapefile_and_layer(layer_name):
    """
    Deleta os arquivos relacionados ao shapefile e remove a camada do QGIS.

    :param layer_name: Nome da camada a ser removida e deletada.
    """
    # Iterar sobre as camadas do projeto para encontrar a desejada
    for layer in QgsProject.instance().mapLayers().values():
        if layer.name() == layer_name:
            # Obter o caminho da origem da camada
            layer_source = layer.source()
            layer_dir = os.path.dirname(layer_source)
            base_name = os.path.splitext(os.path.basename(layer_source))[0]
            
            # Remover a camada do QGIS
            QgsProject.instance().removeMapLayer(layer.id())
            print(f"Camada '{layer_name}' foi removida do QGIS.")
            # Apagar os arquivos associados ao shapefile
            extensions = [".shp", ".shx", ".dbf", ".prj", ".qpj", ".cpg"]
            for ext in extensions:
                file_path = os.path.join(layer_dir, base_name + ext)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    print(f"Arquivo deletado: {file_path}")
            return

    pass




def cria_pontos_delta_H(parent, pathTalvegue, project_directory, total_length_degrees):
    
    try:
        processing.run("native:pointsalonglines", {
            'INPUT': pathTalvegue,
            'DISTANCE': total_length_degrees*0.9999,
            'START_OFFSET': 0,
            'END_OFFSET': 0,
            'OUTPUT': project_directory + "/Pontos_delta_H.shp"
        })
    except:
        processing.run("native:pointsalonglines", {
            'INPUT': pathTalvegue,
            'DISTANCE': total_length_degrees*0.9999,
            'START_OFFSET': 0,
            'END_OFFSET': 0,
            'OUTPUT': project_directory
        })




    pontos_layer = QgsVectorLayer(project_directory + "/Pontos_delta_H.shp", "Pontos_Delta_H", "ogr")
    if not(pontos_layer.isValid()):
        QMessageBox.information(parent, "Erro", 'Você deve excluir a camada "Pontos_delta_H" antes de calcular para evitar esta mensagem de erro!')
        return False
    else:
        return True
