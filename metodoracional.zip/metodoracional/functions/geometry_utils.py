from qgis.core import QgsVectorLayer, QgsCoordinateTransform, QgsCoordinateReferenceSystem, QgsProject, QgsGeometry
from qgis.PyQt.QtWidgets import QMessageBox



def comprimento_talvegue(parent, layer_path):

    try:

        layer = QgsVectorLayer(layer_path, "Vector Layer", "ogr")

        source_crs = layer.crs()
        print(f"Sistema de coordenadas de origem da camada {layer_path.split('/')[-1]}: {source_crs.authid()}")

        if not layer.isValid():
                QMessageBox.warning(parent, "Erro",
            f'Erro ao carregar {layer_path.split('/')[-1]} no campo Canal Principal!')

        total_length = 0
        for feature in layer.getFeatures():
            geometry = feature.geometry()
            if geometry:
                total_length += geometry.length()

        return total_length
    
    except Exception as e:
        QMessageBox.warning(parent, "Erro", "Erro ao calcular comprimento do canal principal. Verifique o arquivo shapefile.")
        print(f"[ERRO] {e}")  # Também útil para debug no console

#Converte graus para metro e recalcula o comprimento do talvegue
def converte_grau_para_metro(parent, layer_path, EPSG):
    
    layer = QgsVectorLayer(layer_path, 'Layer Name', 'ogr')

    if not layer.isValid():
        if not layer.isValid():
            QMessageBox.warning(parent, "Erro",
        f'Erro ao converter {layer_path.split("/")[-1]} para metros!')
        return None

    source_crs = layer.crs()
    target_crs = QgsCoordinateReferenceSystem('EPSG:' + EPSG)
    transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())

    total_length_meters = 0
    for feature in layer.getFeatures():
        geom = feature.geometry()
        if geom.isNull():
            continue

        geom.transform(transform)
        total_length_meters += geom.length()

    return total_length_meters