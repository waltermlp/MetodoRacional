from qgis.core import QgsVectorLayer, QgsGeometry, QgsProject, QgsCoordinateReferenceSystem, QgsCoordinateTransform
import processing
from qgis.PyQt.QtWidgets import QMessageBox, QWidget
import numpy as np

def calcula_delta_H(project_directory, raster_path):
    # Define the output path for the raster sampling function
    shapefile_path = project_directory + '/Sampled.shp'

    try:
        result = processing.run("native:rastersampling", {
            'INPUT': project_directory + "/Pontos_delta_H.shp",
            'RASTERCOPY': raster_path,
            'COLUMN_PREFIX': 'SAMPLE_',
            'OUTPUT': shapefile_path
        })
    except Exception as e:
        QMessageBox.warning(QWidget(), "Erro", "Erro no processamento do modelo digital de elevação ao extrair alturas: " + str(e))
        return None

    layer = QgsVectorLayer(result['OUTPUT'], "Pontos_delta_H", "ogr")

    if not layer.isValid():
        QMessageBox.warning(QWidget(), "Erro", "Erro ao carregar pontos para delta_H!")
        return None

    vector = []
    for feature in layer.getFeatures():
        field_name = 'SAMPLE_1'
        if field_name in layer.fields().names():
            attribute_value = feature[field_name]
            vector.append(attribute_value)
        else:
            QMessageBox.warning(QWidget(), "Erro", f"Atributos de altitude não encontrados em {shapefile_path}.")

    if vector:
        delta_h = max(vector) - min(vector)
        print(f"As alturas são {vector} em metros")
        print(f'A diferença de altura do Talvegue é de {delta_h} metros')
        return delta_h
    else:
        print("Nenhuma diferença de altura calculada.")
        return None




def calcula_area_bacia(EPSG,caminho_shapefile, parent=None):

    try:
    
        layer = QgsVectorLayer(caminho_shapefile, "Bacia.shp", "ogr")

        if not layer.isValid():
            QMessageBox.warning(parent, "Erro", f"Erro ao carregar {caminho_shapefile.split('/')[-1]} no campo Canal Principal!")
            return None

        print("Camada Bacia.shp carregada com sucesso.")
        crs_metrico = QgsCoordinateReferenceSystem('EPSG:' + EPSG)
        crs_original = layer.crs()

        total_area = 0
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom:
                geom_metrico = QgsGeometry(geom)
                geom_metrico.transform(QgsCoordinateTransform(crs_original, crs_metrico, QgsProject.instance()))
                total_area += geom_metrico.area()

        print(f"Área calculada: {total_area / 1e6:.4f} km²")
        return total_area / 1e6
    

    except Exception as e:
        QMessageBox.warning(parent, "Erro", f"Erro ao calcular area da Bacia!")
        print(f"[ERRO] {e}")  # Também útil para debug no console







def calcula_Tc(total_length, delta_h, area_Km):

    L_km = total_length/1000

# Se a área da bacia for maior que 1 km², o tempo de concentração é calculado pela fórmula de Kirpich modificado
    if area_Km > 0.45:
        Tc = 1.42 * ((((L_km)** 3) / delta_h)**0.385)#Kirpich modificado
    else:
        Tc = 0.95 * ((((L_km)** 3) / delta_h)**0.385) #Kirpich simplificado
    
    
    print(f"Tempo de concentração calculado: {Tc:.2f} horas")
    return Tc





def escolher_alpha(duracao):   

    if duracao < 7.5:
        alpha = .108

    elif duracao >= 7.5 and duracao < 22.5:
        alpha = .122
    
    elif duracao >= 22.5 and duracao < 45:
        alpha = .138

    elif duracao >= 45 and duracao < 1.5*60:
        alpha = .156

    elif duracao >= 1.5*60 and duracao < 3*60:
        alpha = .166    
    
    elif duracao >= 3*60 and duracao < 6*60:    
        alpha = .174

    elif duracao >= 6*60 and duracao < 11*60:
        alpha = .176

    elif duracao >= 11*60 and duracao < 19*60:
        aplha = .174

    elif duracao >= 19*60 and duracao < 36*60:
        alpha = .17

    elif duracao >= 36*60 and duracao < 2.5*24*60:
        alpha = .166

    elif duracao >= 2.5*24*60 and duracao < 2.5*24*60:
        alpha = .16

    elif duracao >= 2.5*24*60 and duracao < 3.5*24*60:
        alpha = .156

    else:
        alpha = .152

    return alpha

        

def Calcula_Chuva_projeto(alpha,beta,TR,gama,a,b,c,duracao):
    duracao = duracao / 60 # Convertendo para horas
    I = (TR**(alpha + (beta/(TR**gama)))*((a*duracao) + ((b*np.log10(1+(c*duracao))))))
    return I

def Calcula_vazao_projeto(runoff, I, area_Km):
    Q = (runoff * I * area_Km) / 3.6
    print(f"Vazão de projeto: {Q:.4f} m³/s")
    return Q
